var tituloOriginal = "Bienvenidos a mi pagina web!" ;
        var tituloCambiado = "Esto es una función de JavaScript para cambiar el título";
        var tituloActual = tituloOriginal;

        function cambiar() {
            var tituloElement = document.getElementById("titulo");
            if (tituloActual === tituloOriginal) {
                tituloElement.innerHTML = tituloCambiado;
                tituloElement.style.color = "blue"; // Cambia el color del título a azul
                tituloActual = tituloCambiado;
            } else {
                tituloElement.innerHTML = tituloOriginal;
                tituloElement.style.color = "white"; // Cambia el color del título
                tituloActual = tituloOriginal;
            }
        }

        document.addEventListener("scroll", function() {
            var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            var documentHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
            var windowHeight = window.innerHeight;
            var scrollPercentage = (scrollTop / (documentHeight - windowHeight)) * 100;
            var progressBar = document.getElementById("progress-bar");
            progressBar.style.width = scrollPercentage + "%";

            var scrollButton = document.getElementById("scroll-to-top");
            if (scrollTop > 100) {
                scrollButton.style.display = "block";
            } else {
                scrollButton.style.display = "none";
            }
        });

        function scrollToTop() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }